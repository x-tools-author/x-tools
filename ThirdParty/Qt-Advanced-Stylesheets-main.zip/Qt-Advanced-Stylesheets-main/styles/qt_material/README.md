# Qt-Material

This stylesheet has ben copied from the [Qt-material](https://github.com/UN-GCPDS/qt-material) 
roject from [GCPDS](https://github.com/UN-GCPDS). File any pull requests for
this stylesheet and any improvements or changes to the original project.