# Qt Conding Style
See [Qt Coding Style Doc](http://wiki.qt.io/Qt_Coding_Style)

# Qt Conding Conventions
See [Qt Coding Conventions Doc](http://wiki.qt.io/Coding_Conventions)
