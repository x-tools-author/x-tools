# Tested Environments

## Qt with Compiler Environment

| Qt     | Tool               | OS                        | 
| ------ | ------------------ | ------------------------- | 
| 5.15   | MingW 64 bit       | Windows 64bit             | 
| ------ | ------------------ | ------------------------- | 
| 6.4.1  | gcc 11.3           | Linux   64bit             | 
| ------ | ------------------ | ------------------------- | 


- As the code is upgraded, old Qt may not be supported.
- If more funding is raised, we will also support MacOS testing.
