/***************************************************************************************************
 * Copyright 2023-2025 x-tools-author(x-tools@outlook.com). All rights reserved.
 *
 * The file is encoded using "utf8 with bom", it is a part of xTools project.
 *
 * xTools is licensed according to the terms in the file LICENCE(GPL V3) in the root of the source
 * code directory.
 **************************************************************************************************/
#pragma once

#include <QStyledItemDelegate>

class SocketStyledItemDelegate : public QStyledItemDelegate
{
    Q_OBJECT
public:
    SocketStyledItemDelegate(QObject *parent = Q_NULLPTR);
    ~SocketStyledItemDelegate() override;

    // clang-format off
    QWidget *createEditor(QWidget *parent, const QStyleOptionViewItem &option, const QModelIndex &index) const override;
    void setEditorData(QWidget *editor, const QModelIndex &index) const override;
    void setModelData(QWidget *editor, QAbstractItemModel *model, const QModelIndex &index) const override;
    // clang-format on
};
